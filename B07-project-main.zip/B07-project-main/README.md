# B07-project

Welcome to the GitHub repository for the B07-project group's CSCB07 project.

## Team Members
- Alankrit Verma
- Andrew Chen
- Aryan Jain
- Lyam Katz
- Leo Liao

## Project Information

**Name:** B07-project

**Namespace:** com.example.b07_project

**Compile SDK:** 34a
