package com.example.b07_project.pages.store;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.b07_project.R;

public class store_description extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_description);
    }
}