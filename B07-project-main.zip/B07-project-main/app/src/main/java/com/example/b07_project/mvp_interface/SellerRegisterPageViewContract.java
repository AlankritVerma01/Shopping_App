package com.example.b07_project.mvp_interface;

public interface SellerRegisterPageViewContract extends RegisterPageContract.View {
    String getShopName();
}
