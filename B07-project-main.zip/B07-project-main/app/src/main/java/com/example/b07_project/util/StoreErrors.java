package com.example.b07_project.util;

public enum StoreErrors {
    ;

    public enum NameError {
        EMPTY,
        TOO_LONG
    }

    public enum DescError { }
}
